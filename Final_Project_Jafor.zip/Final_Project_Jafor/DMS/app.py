from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Database connection
def connect_db():
    conn = sqlite3.connect("drugs.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS drugs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            dosage TEXT NOT NULL,
            manufacturer TEXT NOT NULL,
            expiry_date TEXT NOT NULL,
            price REAL NOT NULL
        )
    """)
    conn.commit()
    return conn

# Home page
@app.route("/")
def home():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM drugs")
    drugs = cursor.fetchall()
    conn.close()
    return render_template("home.html", drugs=drugs)

# Add drug
@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        name = request.form["name"]
        dosage = request.form["dosage"]
        manufacturer = request.form["manufacturer"]
        expiry_date = request.form["expiry_date"]
        price = request.form["price"]

        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO drugs (name, dosage, manufacturer, expiry_date, price)
            VALUES (?, ?, ?, ?, ?)
        """, (name, dosage, manufacturer, expiry_date, price))
        conn.commit()
        conn.close()
        return redirect(url_for("home"))

    return render_template("add.html")

# Update drug
@app.route("/update/<int:drug_id>", methods=["GET", "POST"])
def update(drug_id):
    conn = connect_db()
    cursor = conn.cursor()

    if request.method == "POST":
        name = request.form["name"]
        dosage = request.form["dosage"]
        manufacturer = request.form["manufacturer"]
        expiry_date = request.form["expiry_date"]
        price = request.form["price"]

        cursor.execute("""
            UPDATE drugs 
            SET name = ?, dosage = ?, manufacturer = ?, expiry_date = ?, price = ?
            WHERE id = ?
        """, (name, dosage, manufacturer, expiry_date, price, drug_id))
        conn.commit()
        conn.close()
        return redirect(url_for("home"))

    cursor.execute("SELECT * FROM drugs WHERE id = ?", (drug_id,))
    drug = cursor.fetchone()
    conn.close()
    return render_template("update.html", drug=drug)

# Delete drug
@app.route("/delete/<int:drug_id>")
def delete(drug_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM drugs WHERE id = ?", (drug_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
